#include "User.h"
#include "Utils.h"
#include <sstream>

using namespace std;

User::User() : creditPoints(0) {}

User::User(string userId, string name, string studentId, string email,
           string phone, string department, string semester,
           string password, int creditPoints)
    : userId(userId), name(name), studentId(studentId), email(email),
      phone(phone), department(department), semester(semester),
      password(password), creditPoints(creditPoints) {}

string User::getUserId() const { return userId; }
string User::getName() const { return name; }
string User::getStudentId() const { return studentId; }
string User::getEmail() const { return email; }
string User::getPhone() const { return phone; }
string User::getDepartment() const { return department; }
string User::getSemester() const { return semester; }
string User::getPassword() const { return password; }
int User::getCreditPoints() const { return creditPoints; }

void User::setName(const string &v) { name = v; }
void User::setEmail(const string &v) { email = v; }
void User::setPhone(const string &v) { phone = v; }
void User::setDepartment(const string &v) { department = v; }
void User::setSemester(const string &v) { semester = v; }
void User::setPassword(const string &v) { password = v; }
void User::setCreditPoints(int v) { creditPoints = v; }
void User::addCreditPoints(int delta) { creditPoints += delta; }

string User::toLine() const {
    ostringstream oss;
    oss << userId << "|" << name << "|" << studentId << "|" << email << "|"
        << phone << "|" << department << "|" << semester << "|" << password
        << "|" << creditPoints;
    return oss.str();
}

User User::fromLine(const string &line) {
    vector<string> f = splitLine(line, '|');
    while (f.size() < 9) f.push_back("");
    int pts = 0;
    try { pts = stoi(f[8]); } catch (...) { pts = 0; }
    return User(f[0], f[1], f[2], f[3], f[4], f[5], f[6], f[7], pts);
}