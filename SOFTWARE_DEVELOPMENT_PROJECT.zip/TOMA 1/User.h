#ifndef USER_H
#define USER_H

#include <string>

class User {
private:
    std::string userId;
    std::string name;
    std::string studentId;
    std::string email;
    std::string phone;
    std::string department;
    std::string semester;
    std::string password;
    int creditPoints;

public:
    User();
    User(std::string userId, std::string name, std::string studentId, std::string email,
         std::string phone, std::string department, std::string semester,
         std::string password, int creditPoints);

    std::string getUserId() const;
    std::string getName() const;
    std::string getStudentId() const;
    std::string getEmail() const;
    std::string getPhone() const;
    std::string getDepartment() const;
    std::string getSemester() const;
    std::string getPassword() const;
    int getCreditPoints() const;

    void setName(const std::string &v);
    void setEmail(const std::string &v);
    void setPhone(const std::string &v);
    void setDepartment(const std::string &v);
    void setSemester(const std::string &v);
    void setPassword(const std::string &v);
    void setCreditPoints(int v);
    void addCreditPoints(int delta);

    std::string toLine() const;
    static User fromLine(const std::string &line);
};

#endif