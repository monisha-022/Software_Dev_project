#include "Request.h"
#include "Utils.h"
#include <sstream>

using namespace std;

Request::Request() : status("Pending") {}

Request::Request(string requestId, string requesterId, string resourceId,
                  string ownerId, string requestDate, string status)
    : requestId(requestId), requesterId(requesterId), resourceId(resourceId),
      ownerId(ownerId), requestDate(requestDate), status(status) {}

string Request::getRequestId() const { return requestId; }
string Request::getRequesterId() const { return requesterId; }
string Request::getResourceId() const { return resourceId; }
string Request::getOwnerId() const { return ownerId; }
string Request::getRequestDate() const { return requestDate; }
string Request::getStatus() const { return status; }

void Request::setStatus(const string &v) { status = v; }

string Request::toLine() const {
    ostringstream oss;
    oss << requestId << "|" << requesterId << "|" << resourceId << "|" << ownerId << "|"
        << requestDate << "|" << status;
    return oss.str();
}

Request Request::fromLine(const string &line) {
    vector<string> f = splitLine(line, '|');
    while (f.size() < 6) f.push_back("");
    return Request(f[0], f[1], f[2], f[3], f[4], f[5]);
}