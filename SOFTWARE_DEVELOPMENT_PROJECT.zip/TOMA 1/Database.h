#ifndef DATABASE_H
#define DATABASE_H

#include <vector>
#include "User.h"
#include "Resource.h"
#include "BorrowRecord.h"
#include "Request.h"
#include "ExchangeRequest.h"
#include "Admin.h"

struct Database {
    std::vector<User> users;
    std::vector<Resource> resources;
    std::vector<BorrowRecord> borrowings;
    std::vector<Request> requests;
    std::vector<ExchangeRequest> exchanges;
    Admin admin;
};

#endif