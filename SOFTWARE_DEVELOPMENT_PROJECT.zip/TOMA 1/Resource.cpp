#include "Resource.h"
#include "Utils.h"
#include <sstream>

using namespace std;

Resource::Resource() : status("Available"), borrowerId("None"), dueDate("None") {}

Resource::Resource(string resourceId, string name, string type, string subject,
                    string description, string ownerId, string author,
                    string condition, string status, string borrowerId, string dueDate)
    : resourceId(resourceId), name(name), type(type), subject(subject),
      description(description), ownerId(ownerId), author(author), condition(condition),
      status(status), borrowerId(borrowerId), dueDate(dueDate) {}

string Resource::getResourceId() const { return resourceId; }
string Resource::getName() const { return name; }
string Resource::getType() const { return type; }
string Resource::getSubject() const { return subject; }
string Resource::getDescription() const { return description; }
string Resource::getOwnerId() const { return ownerId; }
string Resource::getAuthor() const { return author; }
string Resource::getCondition() const { return condition; }
string Resource::getStatus() const { return status; }
string Resource::getBorrowerId() const { return borrowerId; }
string Resource::getDueDate() const { return dueDate; }

void Resource::setOwnerId(const string &v) { ownerId = v; }
void Resource::setName(const string &v) { name = v; }
void Resource::setType(const string &v) { type = v; }
void Resource::setSubject(const string &v) { subject = v; }
void Resource::setDescription(const string &v) { description = v; }
void Resource::setAuthor(const string &v) { author = v; }
void Resource::setCondition(const string &v) { condition = v; }
void Resource::setStatus(const string &v) { status = v; }
void Resource::setBorrowerId(const string &v) { borrowerId = v; }
void Resource::setDueDate(const string &v) { dueDate = v; }

bool Resource::isAvailable() const { return status == "Available"; }

string Resource::toLine() const {
    ostringstream oss;
    oss << resourceId << "|" << name << "|" << type << "|" << subject << "|"
        << description << "|" << ownerId << "|" << author << "|" << condition << "|"
        << status << "|" << borrowerId << "|" << dueDate;
    return oss.str();
}

Resource Resource::fromLine(const string &line) {
    vector<string> f = splitLine(line, '|');
    while (f.size() < 11) f.push_back("None");
    return Resource(f[0], f[1], f[2], f[3], f[4], f[5], f[6], f[7], f[8], f[9], f[10]);
}