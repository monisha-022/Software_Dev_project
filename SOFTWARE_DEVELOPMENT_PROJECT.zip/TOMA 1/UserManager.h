#ifndef USERMANAGER_H
#define USERMANAGER_H

#include "Database.h"
#include "FileManager.h"

class UserManager {
private:
    Database &db;
    FileManager &fm;

public:
    UserManager(Database &db, FileManager &fm);

    void registerStudent();
    User* login(const std::string &idOrStudentId, const std::string &password);
    bool adminLogin(const std::string &username, const std::string &password);

    User* findByUserId(const std::string &userId);
    User* findByStudentId(const std::string &studentId);
    bool userIdExists(const std::string &userId);
    bool studentIdExists(const std::string &studentId);
    std::string generateNewUserId();

    void viewProfile(const User &u);
    void viewAllUsersAdmin();
    void searchUsersAdmin();
    void deleteUserAdmin();
};

#endif