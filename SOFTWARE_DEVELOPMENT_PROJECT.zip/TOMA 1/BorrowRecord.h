#ifndef BORROWRECORD_H
#define BORROWRECORD_H

#include <string>

class BorrowRecord {
private:
    std::string borrowId;
    std::string userId;
    std::string resourceId;
    std::string resourceName;
    std::string borrowDate;
    std::string dueDate;
    std::string returnDate;
    std::string status;

public:
    BorrowRecord();
    BorrowRecord(std::string borrowId, std::string userId, std::string resourceId,
                 std::string resourceName, std::string borrowDate, std::string dueDate,
                 std::string returnDate, std::string status);

    std::string getBorrowId() const;
    std::string getUserId() const;
    std::string getResourceId() const;
    std::string getResourceName() const;
    std::string getBorrowDate() const;
    std::string getDueDate() const;
    std::string getReturnDate() const;
    std::string getStatus() const;

    void setReturnDate(const std::string &v);
    void setStatus(const std::string &v);

    std::string toLine() const;
    static BorrowRecord fromLine(const std::string &line);
};

#endif