#ifndef REPORTMANAGER_H
#define REPORTMANAGER_H

#include "Database.h"
#include "ResourceManager.h"

class ReportManager {
private:
    Database &db;
    ResourceManager &rm;

public:
    ReportManager(Database &db, ResourceManager &rm);

    void viewLeaderboard();
    void viewResourceStatistics();
    void generateUserReport();
    void generateResourceReport();
    void generateBorrowingReport();
    void generateContributionReport();
    void generateAllReportsMenu();
};

#endif