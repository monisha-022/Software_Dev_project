#ifndef RESOURCEMANAGER_H
#define RESOURCEMANAGER_H

#include "Database.h"
#include "FileManager.h"
#include <vector>
#include <string>

class Resource;
class User;


class ResourceManager {
private:
    Database &db;
    FileManager &fm;

    void displayResourceTable(const std::vector<Resource*> &list);

public:
    ResourceManager(Database &db, FileManager &fm);

    Resource* findById(const std::string &resourceId);
    std::string generateNewResourceId();

    void resourceLibraryMenu(const std::string &currentUserId);
    void viewAllResources();
    void viewByType(const std::string &type);
    void viewSubjectWise();
    void searchResources();
    void filterResourcesMenu();
    int viewResourceDetailsInteractive(std::string &outResourceId);
    void printResourceDetails(const Resource &r);

    void addResource(User &owner);
    void myResources(const std::string &userId);
    void updateResource(const std::string &userId, bool isAdmin);
    void deleteResource(const std::string &userId, bool isAdmin);

    void adminAddResource();
    void adminViewAllResources();

    int countByStatus(const std::string &status) const;
    int countByType(const std::string &type) const;
};

#endif