#ifndef EXCHANGEREQUEST_H
#define EXCHANGEREQUEST_H

#include <string>

class ExchangeRequest {
private:
    std::string exchangeId;
    std::string senderId;
    std::string senderResourceId;
    std::string receiverId;
    std::string requestedResourceId;
    std::string date;
    std::string status;

public:
    ExchangeRequest();
    ExchangeRequest(std::string exchangeId, std::string senderId, std::string senderResourceId,
                     std::string receiverId, std::string requestedResourceId,
                     std::string date, std::string status);

    std::string getExchangeId() const;
    std::string getSenderId() const;
    std::string getSenderResourceId() const;
    std::string getReceiverId() const;
    std::string getRequestedResourceId() const;
    std::string getDate() const;
    std::string getStatus() const;

    void setStatus(const std::string &v);

    std::string toLine() const;
    static ExchangeRequest fromLine(const std::string &line);
};

#endif