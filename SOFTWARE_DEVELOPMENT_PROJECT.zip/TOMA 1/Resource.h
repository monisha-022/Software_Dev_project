#ifndef RESOURCE_H
#define RESOURCE_H

#include <string>

class Resource {
private:
    std::string resourceId;
    std::string name;
    std::string type;
    std::string subject;
    std::string description;
    std::string ownerId;
    std::string author;
    std::string condition;
    std::string status;
    std::string borrowerId;
    std::string dueDate;

public:
    Resource();
    Resource(std::string resourceId, std::string name, std::string type, std::string subject,
              std::string description, std::string ownerId, std::string author,
              std::string condition, std::string status, std::string borrowerId,
              std::string dueDate);

    std::string getResourceId() const;
    std::string getName() const;
    std::string getType() const;
    std::string getSubject() const;
    std::string getDescription() const;
    std::string getOwnerId() const;
    std::string getAuthor() const;
    std::string getCondition() const;
    std::string getStatus() const;
    std::string getBorrowerId() const;
    std::string getDueDate() const;

    void setOwnerId(const std::string &v);
    void setName(const std::string &v);
    void setType(const std::string &v);
    void setSubject(const std::string &v);
    void setDescription(const std::string &v);
    void setAuthor(const std::string &v);
    void setCondition(const std::string &v);
    void setStatus(const std::string &v);
    void setBorrowerId(const std::string &v);
    void setDueDate(const std::string &v);

    bool isAvailable() const;

    std::string toLine() const;
    static Resource fromLine(const std::string &line);
};

#endif