#include "Utils.h"
#include <iostream>
#include <sstream>
#include <algorithm>
#include <cctype>
#include <ctime>
#include <limits>

using namespace std;

string trim(const string &s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == string::npos) return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

string toLower(const string &s) {
    string result = s;
    transform(result.begin(), result.end(), result.begin(), ::tolower);
    return result;
}

vector<string> splitLine(const string &line, char delim) {
    vector<string> tokens;
    stringstream ss(line);
    string item;
    while (getline(ss, item, delim)) {
        tokens.push_back(item);
    }
    if (!line.empty() && line.back() == delim) {
        tokens.push_back("");
    }
    return tokens;
}

string padRight(const string &s, size_t width) {
    if (s.length() >= width) return s.substr(0, width);
    return s + string(width - s.length(), ' ');
}

bool containsIgnoreCase(const string &haystack, const string &needle) {
    string h = toLower(haystack);
    string n = toLower(needle);
    return h.find(n) != string::npos;
}

int extractNumber(const string &id) {
    string digits;
    for (char c : id) {
        if (isdigit((unsigned char)c)) digits += c;
    }
    if (digits.empty()) return 0;
    try {
        return stoi(digits);
    } catch (...) {
        return 0;
    }
}

bool isValidEmail(const string &email) {
    if (email.empty()) return false;
    size_t at = email.find('@');
    if (at == string::npos || at == 0 || at == email.length() - 1) return false;
    size_t dot = email.find('.', at);
    if (dot == string::npos || dot == email.length() - 1) return false;
    if (email.find(' ') != string::npos) return false;
    return true;
}

bool isValidPhone(const string &phone) {
    if (phone.length() < 7 || phone.length() > 15) return false;
    for (char c : phone) {
        if (!isdigit((unsigned char)c)) return false;
    }
    return true;
}

bool isNonEmpty(const string &s) {
    return !trim(s).empty();
}

bool isValidSemester(const string &s) {
    if (!isNonEmpty(s)) return false;
    for (char c : s) if (!isdigit((unsigned char)c)) return false;
    int val = stoi(s);
    return val >= 1 && val <= 12;
}

int readMenuChoice(const string &prompt, int minVal, int maxVal) {
    while (true) {
        cout << prompt;
        string line;
        if (!getline(cin, line)) {
            cout << "\n[INFO] Input stream closed. Exiting application.\n";
            exit(0);
        }
        line = trim(line);
        if (line.empty()) {
            printError("Input cannot be empty. Please try again.");
            continue;
        }
        bool numeric = true;
        for (char c : line) {
            if (!isdigit((unsigned char)c) && !(c == '-' )) { numeric = false; break; }
        }
        if (!numeric) {
            printError("Invalid choice. Please enter a number.");
            continue;
        }
        try {
            int val = stoi(line);
            if (val < minVal || val > maxVal) {
                printError("Choice out of range. Try again.");
                continue;
            }
            return val;
        } catch (...) {
            printError("Invalid numeric input.");
        }
    }
}

string readLine(const string &prompt) {
    cout << prompt;
    string line;
    if (!getline(cin, line)) {
        cout << "\n[INFO] Input stream closed. Exiting application.\n";
        exit(0);
    }
    return trim(line);
}

string readPassword(const string &prompt) {
    cout << prompt;
    string line;
    if (!getline(cin, line)) {
        cout << "\n[INFO] Input stream closed. Exiting application.\n";
        exit(0);
    }
    return trim(line);
}

string getCurrentDate() {
    time_t now = time(nullptr);
    tm *ltm = localtime(&now);
    char buf[11];
    snprintf(buf, sizeof(buf), "%02d-%02d-%04d", ltm->tm_mday, 1 + ltm->tm_mon, 1900 + ltm->tm_year);
    return string(buf);
}

static bool parseDate(const string &date, int &d, int &m, int &y) {
    if (date.length() != 10) return false;
    if (date[2] != '-' || date[5] != '-') return false;
    try {
        d = stoi(date.substr(0, 2));
        m = stoi(date.substr(3, 2));
        y = stoi(date.substr(6, 4));
    } catch (...) {
        return false;
    }
    return true;
}

bool isValidDate(const string &date) {
    int d, m, y;
    if (!parseDate(date, d, m, y)) return false;
    if (m < 1 || m > 12) return false;
    if (d < 1 || d > 31) return false;
    if (y < 2000 || y > 2100) return false;
    return true;
}

string addDaysToDate(const string &date, int days) {
    int d, m, y;
    if (!parseDate(date, d, m, y)) return date;
    tm t = {};
    t.tm_mday = d;
    t.tm_mon = m - 1;
    t.tm_year = y - 1900;
    t.tm_hour = 12;
    time_t tt = mktime(&t);
    tt += (time_t)days * 24 * 60 * 60;
    tm *nt = localtime(&tt);
    char buf[11];
    snprintf(buf, sizeof(buf), "%02d-%02d-%04d", nt->tm_mday, 1 + nt->tm_mon, 1900 + nt->tm_year);
    return string(buf);
}

int compareDates(const string &d1, const string &d2) {
    int d1d, d1m, d1y, d2d, d2m, d2y;
    if (!parseDate(d1, d1d, d1m, d1y) || !parseDate(d2, d2d, d2m, d2y)) return 0;
    if (d1y != d2y) return d1y - d2y;
    if (d1m != d2m) return d1m - d2m;
    return d1d - d2d;
}

void printLine(char ch, int length) {
    cout << string(length, ch) << "\n";
}

void printHeader(const string &title) {
    cout << Color::BLUE;
    printLine('=');
    int pad = (62 - (int)title.length()) / 2;
    if (pad < 0) pad = 0;
    cout << string(pad, ' ') << title << "\n";
    printLine('=');
    cout << Color::RESET;
}

void printSubHeader(const string &title) {
    cout << Color::CYAN;
    printLine('-');
    cout << title << "\n";
    printLine('-');
    cout << Color::RESET;
}

void printSuccess(const string &msg) {
    cout << Color::GREEN << "[SUCCESS] " << msg << Color::RESET << "\n";
}

void printError(const string &msg) {
    cout << Color::RED << "[ERROR] " << msg << Color::RESET << "\n";
}

void printWarning(const string &msg) {
    cout << Color::YELLOW << "[WARNING] " << msg << Color::RESET << "\n";
}

void printInfo(const string &msg) {
    cout << Color::CYAN << "[INFO] " << msg << Color::RESET << "\n";
}

void pauseScreen() {
    cout << "\nPress ENTER to continue...";
    string dummy;
    if (!getline(cin, dummy)) {
        cout << "\n[INFO] Input stream closed. Exiting application.\n";
        exit(0);
    }
}