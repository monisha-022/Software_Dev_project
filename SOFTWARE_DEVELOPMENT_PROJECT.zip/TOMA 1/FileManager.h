#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include <string>
#include "Database.h"

class FileManager {
private:
    std::string filePath;
    void seedInitialData(Database &db);

public:
    FileManager(const std::string &path = "database.txt");

    bool fileExists() const;
    void initializeDatabase(Database &db);
    bool loadData(Database &db);
    bool saveData(const Database &db);

    std::string generateNextId(const std::string &prefix, int width, int currentMax) const;
};

#endif