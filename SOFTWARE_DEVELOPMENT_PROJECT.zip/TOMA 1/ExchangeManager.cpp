#include "ExchangeManager.h"
#include "Utils.h"
#include <iostream>
#include <algorithm>

using namespace std;

ExchangeManager::ExchangeManager(Database &db, FileManager &fm, ResourceManager &rm, UserManager &um)
    : db(db), fm(fm), rm(rm), um(um) {}

string ExchangeManager::generateNewExchangeId() {
    int maxNum = 0;
    for (auto &e : db.exchanges) maxNum = max(maxNum, extractNumber(e.getExchangeId()));
    return fm.generateNextId("E", 3, maxNum);
}

void ExchangeManager::exchangeResourceById(const string &userId, const string &requestedResourceId) {
    Resource *requested = rm.findById(requestedResourceId);
    if (!requested) { printError("Requested resource not found."); return; }
    if (requested->getOwnerId() == userId) { printError("You cannot exchange for your own resource."); return; }

    printInfo("Now select YOUR resource to offer in exchange.");
    string myResId = readLine("Enter your Resource ID to offer: ");
    Resource *mine = rm.findById(myResId);
    if (!mine) { printError("Your resource not found."); return; }
    if (mine->getOwnerId() != userId) { printError("You can only offer a resource you own."); return; }

    string exId = generateNewExchangeId();
    db.exchanges.push_back(ExchangeRequest(exId, userId, myResId, requested->getOwnerId(),
                                            requestedResourceId, getCurrentDate(), "Pending"));
    fm.saveData(db);

    printSuccess("Exchange request submitted successfully!");
    cout << "Exchange ID: " << exId << " | Status: Pending\n";
}

void ExchangeManager::exchangeResource(const string &userId) {
    string resourceId = readLine("Enter the Resource ID you want (requested resource): ");
    exchangeResourceById(userId, resourceId);
}

void ExchangeManager::viewMyExchanges(const string &userId) {
    printHeader("MY EXCHANGE REQUESTS");
    cout << padRight("EX ID", 7) << padRight("MY RES", 8) << padRight("WANTED RES", 11)
         << padRight("RECEIVER", 9) << padRight("DATE", 13) << padRight("STATUS", 10) << "\n";
    printLine('-', 60);
    bool found = false;
    for (auto &e : db.exchanges) {
        if (e.getSenderId() != userId) continue;
        found = true;
        cout << padRight(e.getExchangeId(), 7) << padRight(e.getSenderResourceId(), 8)
             << padRight(e.getRequestedResourceId(), 11) << padRight(e.getReceiverId(), 9)
             << padRight(e.getDate(), 13) << padRight(e.getStatus(), 10) << "\n";
    }
    if (!found) printInfo("You have no exchange requests.");
}

void ExchangeManager::viewExchangeRequestsAdmin() {
    printHeader("ALL EXCHANGE REQUESTS");
    cout << padRight("EX ID", 7) << padRight("SENDER", 8) << padRight("SEND RES", 9)
         << padRight("RECEIVER", 9) << padRight("WANT RES", 9) << padRight("STATUS", 10) << "\n";
    printLine('-', 60);
    bool found = false;
    for (auto &e : db.exchanges) {
        found = true;
        cout << padRight(e.getExchangeId(), 7) << padRight(e.getSenderId(), 8)
             << padRight(e.getSenderResourceId(), 9) << padRight(e.getReceiverId(), 9)
             << padRight(e.getRequestedResourceId(), 9) << padRight(e.getStatus(), 10) << "\n";
    }
    if (!found) printInfo("No exchange requests found.");
}

void ExchangeManager::processExchangeAdmin() {
    string exId = readLine("Enter Exchange ID to process: ");
    auto it = find_if(db.exchanges.begin(), db.exchanges.end(), [&](const ExchangeRequest &e) {
        return e.getExchangeId() == exId;
    });
    if (it == db.exchanges.end()) { printError("Exchange request not found."); return; }

    cout << "1. Accept (swap ownership)\n2. Reject\n0. Cancel\n";
    int choice = readMenuChoice("Enter your choice: ", 0, 2);
    if (choice == 0) { printInfo("Cancelled."); return; }

    if (choice == 1) {
        Resource *senderRes = rm.findById(it->getSenderResourceId());
        Resource *requestedRes = rm.findById(it->getRequestedResourceId());
        if (senderRes && requestedRes) {
            string senderOwner = senderRes->getOwnerId();
            string receiverOwner = requestedRes->getOwnerId();
            senderRes->setOwnerId(receiverOwner);
            requestedRes->setOwnerId(senderOwner);

            User *sender = um.findByUserId(it->getSenderId());
            User *receiver = um.findByUserId(it->getReceiverId());
            if (sender) sender->addCreditPoints(20);
            if (receiver) receiver->addCreditPoints(20);
        }
        it->setStatus("Completed");
        printSuccess("Exchange accepted, ownership swapped, and marked completed. Both users earned +20 points.");
    } else {
        it->setStatus("Rejected");
        printSuccess("Exchange rejected.");
    }
    fm.saveData(db);
}