#include "FileManager.h"
#include "Utils.h"
#include <fstream>
#include <iostream>
#include <algorithm>

using namespace std;

FileManager::FileManager(const string &path) : filePath(path) {}

bool FileManager::fileExists() const {
    ifstream f(filePath);
    return f.good();
}

static void addRes(vector<Resource> &v, const string &id, const string &name,
                    const string &type, const string &subject, const string &desc,
                    const string &owner, const string &author, const string &condition) {
    v.push_back(Resource(id, name, type, subject, desc, owner, author, condition,
                          "Available", "None", "None"));
}

void FileManager::seedInitialData(Database &db) {

    db.users.push_back(User("U001", "Toma Akter", "ST001", "toma@gmail.com", "01700000001", "CSE", "5", "12345", 85));
    db.users.push_back(User("U002", "Rahim Uddin", "ST002", "rahim@gmail.com", "01800000002", "CSE", "4", "12345", 60));
    db.users.push_back(User("U003", "Karim Hasan", "ST003", "karim@gmail.com", "01900000003", "EEE", "6", "12345", 45));
    db.users.push_back(User("U004", "Nila Sultana", "ST004", "nila@gmail.com", "01600000004", "CSE", "3", "12345", 30));
    db.users.push_back(User("U005", "Sara Islam", "ST005", "sara@gmail.com", "01500000005", "SWE", "5", "12345", 20));

    db.admin = Admin("A001", "admin", "admin123");

    vector<Resource> &r = db.resources;

    addRes(r, "R001", "Let Us C", "Book", "C Programming", "Popular beginner C programming book", "U001", "Yashavant Kanetkar", "Good");
    addRes(r, "R002", "C++ Programming Fundamentals", "Book", "C++", "Comprehensive C++ fundamentals textbook", "U001", "Robert Lafore", "Good");
    addRes(r, "R003", "Data Structures and Algorithms", "Book", "Data Structures", "Classic DSA reference book", "U002", "Narasimha Karumanchi", "Good");
    addRes(r, "R004", "Database System Concepts", "Book", "DBMS", "Standard DBMS university textbook", "U002", "Silberschatz", "Good");
    addRes(r, "R005", "Operating System Concepts", "Book", "Operating System", "Core OS concepts textbook", "U003", "Silberschatz", "Good");
    addRes(r, "R006", "Computer Networks", "Book", "Computer Networks", "Networking fundamentals textbook", "U003", "Andrew S. Tanenbaum", "Good");
    addRes(r, "R007", "Software Engineering", "Book", "Software Engineering", "Software engineering principles book", "U004", "Ian Sommerville", "Good");
    addRes(r, "R008", "Artificial Intelligence Basics", "Book", "Artificial Intelligence", "Introductory AI concepts book", "U004", "Stuart Russell", "Good");

    addRes(r, "R009", "C Programming Complete Notes", "Notes", "C Programming", "Full semester C programming notes", "U001", "University Resource", "Good");
    addRes(r, "R010", "C++ OOP Notes", "Notes", "C++", "Object oriented programming notes", "U001", "University Resource", "Good");
    addRes(r, "R011", "Java Notes", "Notes", "Java", "Core Java concepts notes", "U002", "University Resource", "Good");
    addRes(r, "R012", "DSA Notes", "Notes", "Data Structures", "Data structures and algorithms notes", "U002", "University Resource", "Good");
    addRes(r, "R013", "DBMS Complete Notes", "Notes", "DBMS", "Full DBMS course notes", "U003", "University Resource", "Good");
    addRes(r, "R014", "Operating System Notes", "Notes", "Operating System", "OS scheduling and memory notes", "U003", "University Resource", "Good");
    addRes(r, "R015", "Computer Networks Notes", "Notes", "Computer Networks", "Networking layer-wise notes", "U004", "University Resource", "Good");
    addRes(r, "R016", "Software Engineering Notes", "Notes", "Software Engineering", "SDLC and modeling notes", "U004", "University Resource", "Good");
    addRes(r, "R017", "Digital Logic Notes", "Notes", "Digital Logic Design", "Boolean algebra and circuits notes", "U005", "University Resource", "Good");
    addRes(r, "R018", "Mathematics Notes", "Notes", "Mathematics", "Calculus and algebra notes", "U005", "University Resource", "Good");
    addRes(r, "R019", "Physics Notes", "Notes", "Physics", "Mechanics and waves notes", "U001", "University Resource", "Good");
    addRes(r, "R020", "Chemistry Notes", "Notes", "Chemistry", "Organic and inorganic chemistry notes", "U002", "University Resource", "Good");

    addRes(r, "R021", "C Programming Assignment", "Assignment", "C Programming", "Loop and array based assignment", "U003", "University Resource", "Good");
    addRes(r, "R022", "C++ OOP Assignment", "Assignment", "C++", "Class and inheritance assignment", "U003", "University Resource", "Good");
    addRes(r, "R023", "DSA Assignment", "Assignment", "Data Structures", "Linked list and tree assignment", "U004", "University Resource", "Good");
    addRes(r, "R024", "DBMS Assignment", "Assignment", "DBMS", "SQL query based assignment", "U004", "University Resource", "Good");
    addRes(r, "R025", "Operating System Assignment", "Assignment", "Operating System", "Process scheduling assignment", "U005", "University Resource", "Good");
    addRes(r, "R026", "Computer Networks Assignment", "Assignment", "Computer Networks", "IP addressing assignment", "U005", "University Resource", "Good");
    addRes(r, "R027", "Software Engineering Assignment", "Assignment", "Software Engineering", "UML diagram assignment", "U001", "University Resource", "Good");

    addRes(r, "R028", "C Programming Lab Report", "Lab Report", "C Programming", "Semester lab report compilation", "U002", "University Resource", "Good");
    addRes(r, "R029", "C++ Lab Report", "Lab Report", "C++", "OOP lab exercises report", "U002", "University Resource", "Good");
    addRes(r, "R030", "DBMS Lab Report", "Lab Report", "DBMS", "SQL practical lab report", "U003", "University Resource", "Good");
    addRes(r, "R031", "DSA Lab Report", "Lab Report", "Data Structures", "Data structures lab report", "U003", "University Resource", "Good");
    addRes(r, "R032", "Digital Logic Lab Report", "Lab Report", "Digital Logic Design", "Logic gates lab report", "U004", "University Resource", "Good");
    addRes(r, "R033", "Networking Lab Report", "Lab Report", "Computer Networks", "Packet tracer lab report", "U004", "University Resource", "Good");
    addRes(r, "R034", "Java Lab Report", "Lab Report", "Java", "Java programming lab report", "U005", "University Resource", "Good");

    addRes(r, "R035", "C Programming Previous Question", "Question Paper", "C Programming", "Last 3 years question papers", "U005", "University Archive", "Good");
    addRes(r, "R036", "C++ Previous Question", "Question Paper", "C++", "Previous semester questions", "U001", "University Archive", "Good");
    addRes(r, "R037", "DSA Previous Question", "Question Paper", "Data Structures", "Previous semester questions", "U001", "University Archive", "Good");
    addRes(r, "R038", "DBMS Previous Question", "Question Paper", "DBMS", "Previous semester questions", "U002", "University Archive", "Good");
    addRes(r, "R039", "Mathematics Previous Question", "Question Paper", "Mathematics", "Previous semester questions", "U002", "University Archive", "Good");
    addRes(r, "R040", "Physics Previous Question", "Question Paper", "Physics", "Previous semester questions", "U003", "University Archive", "Good");
    addRes(r, "R041", "Computer Networks Previous Question", "Question Paper", "Computer Networks", "Previous semester questions", "U003", "University Archive", "Good");
    addRes(r, "R042", "Operating System Previous Question", "Question Paper", "Operating System", "Previous semester questions", "U004", "University Archive", "Good");

    addRes(r, "R043", "C++ STL Guide", "Programming Resource", "C++", "Complete STL usage guide", "U004", "University Resource", "Good");
    addRes(r, "R044", "C Programming Cheat Sheet", "Programming Resource", "C Programming", "Quick reference cheat sheet", "U005", "University Resource", "Good");
    addRes(r, "R045", "Java Programming Guide", "Programming Resource", "Java", "Java syntax and examples guide", "U005", "University Resource", "Good");
    addRes(r, "R046", "DSA Practice Problems", "Programming Resource", "Data Structures", "Collection of practice problems", "U001", "University Resource", "Good");
    addRes(r, "R047", "Git and GitHub Guide", "Programming Resource", "Software Engineering", "Version control guide", "U002", "University Resource", "Good");
    addRes(r, "R048", "Programming Roadmap", "Programming Resource", "General", "Step by step programming roadmap", "U003", "University Resource", "Good");
    addRes(r, "R049", "Competitive Programming Guide", "Programming Resource", "Algorithms", "Guide for competitive programming", "U004", "University Resource", "Good");

    addRes(r, "R050", "Scientific Calculator", "Calculator", "Mathematics", "Casio scientific calculator", "U001", "N/A", "Good");
    addRes(r, "R051", "GPA Calculator", "Calculator", "General", "Semester GPA calculator tool", "U002", "N/A", "Good");
    addRes(r, "R052", "CGPA Calculator", "Calculator", "General", "Cumulative GPA calculator tool", "U003", "N/A", "Good");
    addRes(r, "R053", "Programming Calculator", "Calculator", "Mathematics", "Programmable engineering calculator", "U004", "N/A", "Good");
    addRes(r, "R054", "Unit Converter", "Calculator", "Mathematics", "Physical unit conversion tool", "U005", "N/A", "Good");

    addRes(r, "R055", "Dell Laptop", "Laptop", "Computer Lab", "Dell Inspiron for project work", "U001", "N/A", "Good");
    addRes(r, "R056", "HP Laptop", "Laptop", "Computer Lab", "HP Pavilion for lab practice", "U002", "N/A", "Good");
    addRes(r, "R057", "Lenovo ThinkPad", "Laptop", "Computer Lab", "Lenovo ThinkPad for coding", "U003", "N/A", "Good");
    addRes(r, "R058", "ASUS Laptop", "Laptop", "Computer Lab", "ASUS laptop for general use", "U004", "N/A", "Good");
    addRes(r, "R059", "University Lab Laptop", "Laptop", "Computer Lab", "Shared laptop from university lab", "U005", "N/A", "Good");

    addRes(r, "R060", "Scholarship Guide", "Other", "Career", "Guide to available scholarships", "U001", "University Resource", "Good");
    addRes(r, "R061", "Internship Guide", "Other", "Career", "Tips for finding internships", "U002", "University Resource", "Good");
    addRes(r, "R062", "CV / Resume Guide", "Other", "Career", "How to write an effective CV", "U003", "University Resource", "Good");
    addRes(r, "R063", "Exam Preparation Guide", "Other", "Exam Preparation", "Strategies for exam preparation", "U004", "University Resource", "Good");
    addRes(r, "R064", "Career Guide", "Other", "Career", "Overall career planning guide", "U005", "University Resource", "Good");
    addRes(r, "R065", "AI and ML Study Material", "Study Material", "Machine Learning", "Introductory AI/ML study material", "U001", "University Resource", "Good");
    addRes(r, "R066", "Web Development Guide", "Study Material", "Web Development", "HTML CSS JS beginner guide", "U002", "University Resource", "Good");

    addRes(r, "R067", "Computer Architecture PDF", "PDF", "Computer Architecture", "Digital lecture slides in PDF format", "U003", "University Resource", "Good");
    addRes(r, "R068", "Software Engineering PDF", "PDF", "Software Engineering", "SDLC models PDF handout", "U004", "University Resource", "Good");
    addRes(r, "R069", "Machine Learning PDF", "PDF", "Machine Learning", "Introductory ML slides PDF", "U005", "University Resource", "Good");

    for (auto &res : r) {
        if (res.getResourceId() == "R008") {
            res.setStatus("Borrowed");
            res.setBorrowerId("U003");
            res.setDueDate(addDaysToDate(getCurrentDate(), 7));
        }
        if (res.getResourceId() == "R037") {
            res.setStatus("Borrowed");
            res.setBorrowerId("U004");
            res.setDueDate(addDaysToDate(getCurrentDate(), -3));
        }
    }

    db.borrowings.push_back(BorrowRecord("B001", "U003", "R008", "Artificial Intelligence Basics",
                                          getCurrentDate(), addDaysToDate(getCurrentDate(), 7),
                                          "None", "Borrowed"));
    db.borrowings.push_back(BorrowRecord("B002", "U004", "R037", "DSA Previous Question",
                                          addDaysToDate(getCurrentDate(), -10), addDaysToDate(getCurrentDate(), -3),
                                          "None", "Overdue"));

    db.requests.push_back(Request("RQ001", "U002", "R055", "U001", getCurrentDate(), "Pending"));

    db.exchanges.push_back(ExchangeRequest("E001", "U002", "R002", "U001", "R003",
                                            getCurrentDate(), "Pending"));
}

void FileManager::initializeDatabase(Database &db) {
    if (fileExists()) {
        loadData(db);
    } else {
        seedInitialData(db);
        saveData(db);
        cout << Color::GREEN << "[INFO] New database.txt created with preloaded resources.\n" << Color::RESET;
    }
}

bool FileManager::loadData(Database &db) {
    ifstream in(filePath);
    if (!in.is_open()) return false;

    db.users.clear();
    db.resources.clear();
    db.borrowings.clear();
    db.requests.clear();
    db.exchanges.clear();

    string line;
    string section = "";

    while (getline(in, line)) {
        string t = trim(line);
        if (t.empty()) continue;
        if (t[0] == '=' ) continue;
        if (t == "SMART UNIVERSITY RESOURCE DATABASE") continue;

        if (t == "[USERS]") { section = "USERS"; continue; }
        if (t == "[RESOURCES]") { section = "RESOURCES"; continue; }
        if (t == "[BORROWINGS]") { section = "BORROWINGS"; continue; }
        if (t == "[REQUESTS]") { section = "REQUESTS"; continue; }
        if (t == "[EXCHANGES]") { section = "EXCHANGES"; continue; }
        if (t == "[ADMIN]") { section = "ADMIN"; continue; }

        if (section == "USERS") db.users.push_back(User::fromLine(t));
        else if (section == "RESOURCES") db.resources.push_back(Resource::fromLine(t));
        else if (section == "BORROWINGS") db.borrowings.push_back(BorrowRecord::fromLine(t));
        else if (section == "REQUESTS") db.requests.push_back(Request::fromLine(t));
        else if (section == "EXCHANGES") db.exchanges.push_back(ExchangeRequest::fromLine(t));
        else if (section == "ADMIN") db.admin = Admin::fromLine(t);
    }

    in.close();
    return true;
}

bool FileManager::saveData(const Database &db) {
    ofstream out(filePath, ios::trunc);
    if (!out.is_open()) return false;

    out << "========================================\n";
    out << "SMART UNIVERSITY RESOURCE DATABASE\n";
    out << "========================================\n\n";

    out << "[USERS]\n\n";
    for (const auto &u : db.users) out << u.toLine() << "\n";
    out << "\n";

    out << "[RESOURCES]\n\n";
    for (const auto &r : db.resources) out << r.toLine() << "\n";
    out << "\n";

    out << "[BORROWINGS]\n\n";
    for (const auto &b : db.borrowings) out << b.toLine() << "\n";
    out << "\n";

    out << "[REQUESTS]\n\n";
    for (const auto &rq : db.requests) out << rq.toLine() << "\n";
    out << "\n";

    out << "[EXCHANGES]\n\n";
    for (const auto &e : db.exchanges) out << e.toLine() << "\n";
    out << "\n";

    out << "[ADMIN]\n\n";
    out << db.admin.toLine() << "\n";

    out.close();
    return true;
}

string FileManager::generateNextId(const string &prefix, int width, int currentMax) const {
    int next = currentMax + 1;
    string numStr = to_string(next);
    while ((int)numStr.length() < width) numStr = "0" + numStr;
    return prefix + numStr;
}