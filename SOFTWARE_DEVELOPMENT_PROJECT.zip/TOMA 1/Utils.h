#ifndef UTILS_H
#define UTILS_H

#include <string>
#include <vector>

namespace Color {
    const std::string RESET  = "\033[0m";
    const std::string BLUE   = "\033[1;34m";
    const std::string GREEN  = "\033[1;32m";
    const std::string RED    = "\033[1;31m";
    const std::string YELLOW = "\033[1;33m";
    const std::string CYAN   = "\033[1;36m";
    const std::string BOLD   = "\033[1m";
}

std::string trim(const std::string &s);
std::string toLower(const std::string &s);
std::vector<std::string> splitLine(const std::string &line, char delim);
std::string padRight(const std::string &s, size_t width);
bool containsIgnoreCase(const std::string &haystack, const std::string &needle);
int extractNumber(const std::string &id);

bool isValidEmail(const std::string &email);
bool isValidPhone(const std::string &phone);
bool isNonEmpty(const std::string &s);
bool isValidSemester(const std::string &s);
int  readMenuChoice(const std::string &prompt, int minVal, int maxVal);
std::string readLine(const std::string &prompt);
std::string readPassword(const std::string &prompt);

std::string getCurrentDate();
std::string addDaysToDate(const std::string &date, int days);
int compareDates(const std::string &d1, const std::string &d2);
bool isValidDate(const std::string &date);

void printLine(char ch = '=', int length = 62);
void printHeader(const std::string &title);
void printSubHeader(const std::string &title);
void printSuccess(const std::string &msg);
void printError(const std::string &msg);
void printWarning(const std::string &msg);
void printInfo(const std::string &msg);
void pauseScreen();

#endif