#ifndef REQUESTMANAGER_H
#define REQUESTMANAGER_H

#include "Database.h"
#include "FileManager.h"
#include "ResourceManager.h"

class RequestManager {
private:
    Database &db;
    FileManager &fm;
    ResourceManager &rm;

    std::string generateNewRequestId();

public:
    RequestManager(Database &db, FileManager &fm, ResourceManager &rm);

    void requestResource(const std::string &userId);
    void requestResourceById(const std::string &userId, const std::string &resourceId);
    void viewMyRequests(const std::string &userId);
    void viewPendingRequestsAdmin();
    void processRequestAdmin();
};

#endif