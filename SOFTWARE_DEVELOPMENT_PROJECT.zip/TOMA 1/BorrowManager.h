#ifndef BORROWMANAGER_H
#define BORROWMANAGER_H

#include "Database.h"
#include "FileManager.h"
#include "ResourceManager.h"
#include "UserManager.h"

class BorrowManager {
private:
    Database &db;
    FileManager &fm;
    ResourceManager &rm;
    UserManager &um;

    std::string generateNewBorrowId();

public:
    BorrowManager(Database &db, FileManager &fm, ResourceManager &rm, UserManager &um);

    void borrowResource(const std::string &userId);
    void borrowResourceById(const std::string &userId, const std::string &resourceId);
    void returnResource(const std::string &userId);
    void viewBorrowingHistory(const std::string &userId, bool isAdmin);
    void viewOverdueResources(const std::string &userId, bool isAdmin);
    void checkAndUpdateOverdue();
};

#endif