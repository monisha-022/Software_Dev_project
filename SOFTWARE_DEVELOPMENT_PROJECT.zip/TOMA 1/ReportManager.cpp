#include "ReportManager.h"
#include "Utils.h"
#include <iostream>
#include <algorithm>
#include <map>

using namespace std;

ReportManager::ReportManager(Database &db, ResourceManager &rm) : db(db), rm(rm) {}

void ReportManager::viewLeaderboard() {
    printHeader("TOP RESOURCE CONTRIBUTORS");
    vector<User> sorted = db.users;
    sort(sorted.begin(), sorted.end(), [](const User &a, const User &b) {
        return a.getCreditPoints() > b.getCreditPoints();
    });

    cout << padRight("RANK", 8) << padRight("STUDENT", 22) << padRight("POINTS", 8) << "\n";
    printLine('-', 40);
    int rank = 1;
    for (auto &u : sorted) {
        cout << padRight(to_string(rank), 8) << padRight(u.getName(), 22)
             << Color::YELLOW << padRight(to_string(u.getCreditPoints()), 8) << Color::RESET << "\n";
        rank++;
    }
    printLine('-', 40);
}

void ReportManager::viewResourceStatistics() {
    printHeader("RESOURCE STATISTICS");
    int total = (int)db.resources.size();
    cout << "Total Resources: " << total << "\n\n";

    map<string, int> typeCounts;
    for (auto &r : db.resources) typeCounts[r.getType()]++;
    for (auto &kv : typeCounts) {
        cout << padRight(kv.first + ":", 24) << kv.second << "\n";
    }

    cout << "\n";
    int available = rm.countByStatus("Available");
    int borrowed = rm.countByStatus("Borrowed");
    int overdue = 0;
    for (auto &b : db.borrowings) if (b.getStatus() == "Overdue") overdue++;

    cout << Color::GREEN << padRight("Available:", 24) << available << Color::RESET << "\n";
    cout << Color::YELLOW << padRight("Borrowed:", 24) << borrowed << Color::RESET << "\n";
    cout << Color::RED << padRight("Overdue:", 24) << overdue << Color::RESET << "\n";
    printLine('-');
}

void ReportManager::generateUserReport() {
    printSubHeader("USER REPORT");
    cout << "Total Users: " << db.users.size() << "\n\n";

    map<string, int> deptCounts;
    for (auto &u : db.users) deptCounts[u.getDepartment()]++;
    cout << "Users by Department:\n";
    for (auto &kv : deptCounts) cout << "  " << padRight(kv.first + ":", 15) << kv.second << "\n";

    cout << "\nTop Contributors:\n";
    vector<User> sorted = db.users;
    sort(sorted.begin(), sorted.end(), [](const User &a, const User &b) {
        return a.getCreditPoints() > b.getCreditPoints();
    });
    int limit = min((int)sorted.size(), 5);
    for (int i = 0; i < limit; i++) {
        cout << "  " << (i + 1) << ". " << sorted[i].getName() << " - " << sorted[i].getCreditPoints() << " pts\n";
    }
}

void ReportManager::generateResourceReport() {
    printSubHeader("RESOURCE REPORT");
    cout << "Total Resources: " << db.resources.size() << "\n";
    cout << "Available: " << rm.countByStatus("Available") << "\n";
    cout << "Borrowed: " << rm.countByStatus("Borrowed") << "\n";

    int overdue = 0;
    for (auto &b : db.borrowings) if (b.getStatus() == "Overdue") overdue++;
    cout << "Overdue: " << overdue << "\n\n";

    map<string, int> typeCounts, subjectCounts;
    for (auto &r : db.resources) { typeCounts[r.getType()]++; subjectCounts[r.getSubject()]++; }

    cout << "Resources by Category:\n";
    for (auto &kv : typeCounts) cout << "  " << padRight(kv.first + ":", 22) << kv.second << "\n";

    cout << "\nResources by Subject:\n";
    for (auto &kv : subjectCounts) cout << "  " << padRight(kv.first + ":", 22) << kv.second << "\n";
}

void ReportManager::generateBorrowingReport() {
    printSubHeader("BORROWING REPORT");
    int totalTx = (int)db.borrowings.size();
    int returned = 0, currentlyBorrowed = 0, overdue = 0;
    for (auto &b : db.borrowings) {
        if (b.getStatus() == "Returned") returned++;
        else if (b.getStatus() == "Borrowed") currentlyBorrowed++;
        else if (b.getStatus() == "Overdue") overdue++;
    }
    cout << "Total Borrowing Transactions: " << totalTx << "\n";
    cout << "Returned: " << returned << "\n";
    cout << "Currently Borrowed: " << currentlyBorrowed << "\n";
    cout << "Overdue: " << overdue << "\n";
}

void ReportManager::generateContributionReport() {
    printSubHeader("CONTRIBUTION REPORT");
    vector<User> sorted = db.users;
    sort(sorted.begin(), sorted.end(), [](const User &a, const User &b) {
        return a.getCreditPoints() > b.getCreditPoints();
    });
    cout << "Top Contributors:\n";
    int limit = min((int)sorted.size(), 5);
    for (int i = 0; i < limit; i++) {
        cout << "  " << (i + 1) << ". " << sorted[i].getName() << " - " << sorted[i].getCreditPoints() << " pts\n";
    }

    map<string, int> typeCounts, subjectCounts;
    for (auto &r : db.resources) { typeCounts[r.getType()]++; subjectCounts[r.getSubject()]++; }

    string mostSharedType; int maxTypeCount = -1;
    for (auto &kv : typeCounts) if (kv.second > maxTypeCount) { maxTypeCount = kv.second; mostSharedType = kv.first; }

    string mostPopularSubject; int maxSubCount = -1;
    for (auto &kv : subjectCounts) if (kv.second > maxSubCount) { maxSubCount = kv.second; mostPopularSubject = kv.first; }

    cout << "\nMost Shared Category: " << mostSharedType << " (" << maxTypeCount << " resources)\n";
    cout << "Most Popular Subject: " << mostPopularSubject << " (" << maxSubCount << " resources)\n";
}

void ReportManager::generateAllReportsMenu() {
    printHeader("GENERATE REPORTS");
    cout << "1. User Report\n2. Resource Report\n3. Borrowing Report\n4. Contribution Report\n5. All Reports\n0. Back\n";
    int choice = readMenuChoice("Enter your choice: ", 0, 5);
    switch (choice) {
        case 1: generateUserReport(); break;
        case 2: generateResourceReport(); break;
        case 3: generateBorrowingReport(); break;
        case 4: generateContributionReport(); break;
        case 5:
            generateUserReport(); cout << "\n";
            generateResourceReport(); cout << "\n";
            generateBorrowingReport(); cout << "\n";
            generateContributionReport();
            break;
        default: break;
    }
}