#include "RequestManager.h"
#include "Utils.h"
#include <iostream>
#include <algorithm>

using namespace std;

RequestManager::RequestManager(Database &db, FileManager &fm, ResourceManager &rm)
    : db(db), fm(fm), rm(rm) {}

string RequestManager::generateNewRequestId() {
    int maxNum = 0;
    for (auto &rq : db.requests) maxNum = max(maxNum, extractNumber(rq.getRequestId()));
    return fm.generateNextId("RQ", 3, maxNum);
}

void RequestManager::requestResourceById(const string &userId, const string &resourceId) {
    Resource *r = rm.findById(resourceId);
    if (!r) { printError("Resource not found."); return; }
    if (r->getOwnerId() == userId) { printError("You cannot request your own resource."); return; }

    string reqId = generateNewRequestId();
    db.requests.push_back(Request(reqId, userId, resourceId, r->getOwnerId(), getCurrentDate(), "Pending"));
    fm.saveData(db);

    printSuccess("Request submitted successfully!");
    cout << "Request ID: " << reqId << " | Status: Pending\n";
}

void RequestManager::requestResource(const string &userId) {
    string resourceId = readLine("Enter Resource ID to request: ");
    requestResourceById(userId, resourceId);
}

void RequestManager::viewMyRequests(const string &userId) {
    printHeader("MY REQUESTS");
    cout << padRight("REQ ID", 8) << padRight("RESOURCE ID", 12) << padRight("OWNER", 8)
         << padRight("DATE", 13) << padRight("STATUS", 10) << "\n";
    printLine('-', 55);
    bool found = false;
    for (auto &rq : db.requests) {
        if (rq.getRequesterId() != userId) continue;
        found = true;
        cout << padRight(rq.getRequestId(), 8) << padRight(rq.getResourceId(), 12)
             << padRight(rq.getOwnerId(), 8) << padRight(rq.getRequestDate(), 13)
             << padRight(rq.getStatus(), 10) << "\n";
    }
    if (!found) printInfo("You have not made any requests.");
}

void RequestManager::viewPendingRequestsAdmin() {
    printHeader("PENDING RESOURCE REQUESTS");
    cout << padRight("REQ ID", 8) << padRight("REQUESTER", 10) << padRight("RESOURCE ID", 12)
         << padRight("OWNER", 8) << padRight("DATE", 13) << padRight("STATUS", 10) << "\n";
    printLine('-', 65);
    bool found = false;
    for (auto &rq : db.requests) {
        found = true;
        cout << padRight(rq.getRequestId(), 8) << padRight(rq.getRequesterId(), 10)
             << padRight(rq.getResourceId(), 12) << padRight(rq.getOwnerId(), 8)
             << padRight(rq.getRequestDate(), 13) << padRight(rq.getStatus(), 10) << "\n";
    }
    if (!found) printInfo("No requests found.");
}

void RequestManager::processRequestAdmin() {
    string reqId = readLine("Enter Request ID to process: ");
    auto it = find_if(db.requests.begin(), db.requests.end(), [&](const Request &r) {
        return r.getRequestId() == reqId;
    });
    if (it == db.requests.end()) { printError("Request not found."); return; }

    cout << "1. Accept\n2. Reject\n3. Mark Completed\n0. Cancel\n";
    int choice = readMenuChoice("Enter your choice: ", 0, 3);
    if (choice == 1) it->setStatus("Accepted");
    else if (choice == 2) it->setStatus("Rejected");
    else if (choice == 3) it->setStatus("Completed");
    else { printInfo("Cancelled."); return; }

    fm.saveData(db);
    printSuccess("Request status updated to: " + it->getStatus());
}