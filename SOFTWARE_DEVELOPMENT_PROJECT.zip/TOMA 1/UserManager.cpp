#include "UserManager.h"
#include "Utils.h"
#include <iostream>
#include <algorithm>

using namespace std;

UserManager::UserManager(Database &db, FileManager &fm) : db(db), fm(fm) {}

User* UserManager::findByUserId(const string &userId) {
    for (auto &u : db.users) {
        if (u.getUserId() == userId) return &u;
    }
    return nullptr;
}

User* UserManager::findByStudentId(const string &studentId) {
    for (auto &u : db.users) {
        if (u.getStudentId() == studentId) return &u;
    }
    return nullptr;
}

bool UserManager::userIdExists(const string &userId) {
    return findByUserId(userId) != nullptr;
}

bool UserManager::studentIdExists(const string &studentId) {
    return findByStudentId(studentId) != nullptr;
}

string UserManager::generateNewUserId() {
    int maxNum = 0;
    for (auto &u : db.users) {
        maxNum = max(maxNum, extractNumber(u.getUserId()));
    }
    return fm.generateNextId("U", 3, maxNum);
}

void UserManager::registerStudent() {
    printHeader("STUDENT REGISTRATION");

    string name, studentId, email, phone, department, semester, password, confirmPassword;

    while (true) {
        name = readLine("Full Name: ");
        if (!isNonEmpty(name)) { printError("Full name cannot be empty."); continue; }
        break;
    }

    while (true) {
        studentId = readLine("Student ID: ");
        if (!isNonEmpty(studentId)) { printError("Student ID cannot be empty."); continue; }
        if (studentIdExists(studentId)) { printError("This Student ID is already registered."); continue; }
        break;
    }

    while (true) {
        email = readLine("Email: ");
        if (!isValidEmail(email)) { printError("Invalid email format."); continue; }
        break;
    }

    while (true) {
        phone = readLine("Phone Number: ");
        if (!isValidPhone(phone)) { printError("Invalid phone number. Use digits only (7-15 digits)."); continue; }
        break;
    }

    while (true) {
        department = readLine("Department: ");
        if (!isNonEmpty(department)) { printError("Department cannot be empty."); continue; }
        break;
    }

    while (true) {
        semester = readLine("Semester (1-12): ");
        if (!isValidSemester(semester)) { printError("Invalid semester."); continue; }
        break;
    }

    while (true) {
        password = readPassword("Password: ");
        if (!isNonEmpty(password)) { printError("Password cannot be empty."); continue; }
        confirmPassword = readPassword("Confirm Password: ");
        if (password != confirmPassword) { printError("Passwords do not match. Try again."); continue; }
        break;
    }

    string newUserId = generateNewUserId();
    User newUser(newUserId, name, studentId, email, phone, department, semester, password, 0);
    db.users.push_back(newUser);
    fm.saveData(db);

    printSuccess("Registration successful!");
    cout << Color::CYAN << "Your User ID is: " << Color::BOLD << newUserId << Color::RESET << "\n";
    cout << "Please remember this ID for login.\n";
}

User* UserManager::login(const string &idOrStudentId, const string &password) {
    User *u = findByUserId(idOrStudentId);
    if (!u) u = findByStudentId(idOrStudentId);
    if (!u) return nullptr;
    if (u->getPassword() != password) return nullptr;
    return u;
}

bool UserManager::adminLogin(const string &username, const string &password) {
    return db.admin.getUsername() == username && db.admin.getPassword() == password;
}

void UserManager::viewProfile(const User &u) {
    printHeader("STUDENT PROFILE");
    cout << "User ID       : " << u.getUserId() << "\n";
    cout << "Name          : " << u.getName() << "\n";
    cout << "Student ID    : " << u.getStudentId() << "\n";
    cout << "Email         : " << u.getEmail() << "\n";
    cout << "Phone         : " << u.getPhone() << "\n";
    cout << "Department    : " << u.getDepartment() << "\n";
    cout << "Semester      : " << u.getSemester() << "\n";
    cout << Color::YELLOW << "Credit Points : " << u.getCreditPoints() << Color::RESET << "\n";
    printLine('-');
}

void UserManager::viewAllUsersAdmin() {
    printHeader("ALL REGISTERED USERS");
    if (db.users.empty()) {
        printInfo("No users registered yet.");
        return;
    }
    cout << padRight("USER ID", 8) << padRight("NAME", 20) << padRight("STUDENT ID", 12)
         << padRight("DEPT", 8) << padRight("SEM", 5) << padRight("POINTS", 8) << "\n";
    printLine('-', 65);
    for (auto &u : db.users) {
        cout << padRight(u.getUserId(), 8) << padRight(u.getName(), 20)
             << padRight(u.getStudentId(), 12) << padRight(u.getDepartment(), 8)
             << padRight(u.getSemester(), 5) << padRight(to_string(u.getCreditPoints()), 8) << "\n";
    }
    printLine('-', 65);
    cout << "Total Users: " << db.users.size() << "\n";
}

void UserManager::searchUsersAdmin() {
    string keyword = readLine("Enter search keyword (Name / User ID / Student ID / Email): ");
    if (!isNonEmpty(keyword)) { printError("Search keyword cannot be empty."); return; }

    vector<User*> results;
    for (auto &u : db.users) {
        if (containsIgnoreCase(u.getUserId(), keyword) || containsIgnoreCase(u.getName(), keyword) ||
            containsIgnoreCase(u.getStudentId(), keyword) || containsIgnoreCase(u.getEmail(), keyword)) {
            results.push_back(&u);
        }
    }

    if (results.empty()) {
        printWarning("No matching users found.");
        return;
    }

    printSubHeader("SEARCH RESULTS");
    cout << padRight("USER ID", 8) << padRight("NAME", 20) << padRight("STUDENT ID", 12)
         << padRight("DEPT", 8) << padRight("POINTS", 8) << "\n";
    printLine('-', 60);
    for (auto *u : results) {
        cout << padRight(u->getUserId(), 8) << padRight(u->getName(), 20)
             << padRight(u->getStudentId(), 12) << padRight(u->getDepartment(), 8)
             << padRight(to_string(u->getCreditPoints()), 8) << "\n";
    }
}

void UserManager::deleteUserAdmin() {
    string userId = readLine("Enter User ID to delete: ");
    auto it = find_if(db.users.begin(), db.users.end(), [&](const User &u) {
        return u.getUserId() == userId;
    });
    if (it == db.users.end()) {
        printError("User not found.");
        return;
    }
    string confirm = readLine("Are you sure you want to delete this user? (yes/no): ");
    if (toLower(confirm) != "yes") {
        printInfo("Delete cancelled.");
        return;
    }
    db.users.erase(it);
    fm.saveData(db);
    printSuccess("User deleted successfully.");
}