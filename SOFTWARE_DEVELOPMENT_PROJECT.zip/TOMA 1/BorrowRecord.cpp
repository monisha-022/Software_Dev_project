#include "BorrowRecord.h"
#include "Utils.h"
#include <sstream>

using namespace std;

BorrowRecord::BorrowRecord() : returnDate("None"), status("Borrowed") {}

BorrowRecord::BorrowRecord(string borrowId, string userId, string resourceId,
                            string resourceName, string borrowDate, string dueDate,
                            string returnDate, string status)
    : borrowId(borrowId), userId(userId), resourceId(resourceId), resourceName(resourceName),
      borrowDate(borrowDate), dueDate(dueDate), returnDate(returnDate), status(status) {}

string BorrowRecord::getBorrowId() const { return borrowId; }
string BorrowRecord::getUserId() const { return userId; }
string BorrowRecord::getResourceId() const { return resourceId; }
string BorrowRecord::getResourceName() const { return resourceName; }
string BorrowRecord::getBorrowDate() const { return borrowDate; }
string BorrowRecord::getDueDate() const { return dueDate; }
string BorrowRecord::getReturnDate() const { return returnDate; }
string BorrowRecord::getStatus() const { return status; }

void BorrowRecord::setReturnDate(const string &v) { returnDate = v; }
void BorrowRecord::setStatus(const string &v) { status = v; }

string BorrowRecord::toLine() const {
    ostringstream oss;
    oss << borrowId << "|" << userId << "|" << resourceId << "|" << resourceName << "|"
        << borrowDate << "|" << dueDate << "|" << returnDate << "|" << status;
    return oss.str();
}

BorrowRecord BorrowRecord::fromLine(const string &line) {
    vector<string> f = splitLine(line, '|');
    while (f.size() < 8) f.push_back("None");
    return BorrowRecord(f[0], f[1], f[2], f[3], f[4], f[5], f[6], f[7]);
}