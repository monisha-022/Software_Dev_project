#include "ResourceManager.h"
#include "Utils.h"
#include <iostream>
#include <algorithm>

using namespace std;

ResourceManager::ResourceManager(Database &db, FileManager &fm) : db(db), fm(fm) {}

Resource* ResourceManager::findById(const string &resourceId) {
    for (auto &r : db.resources) {
        if (r.getResourceId() == resourceId) return &r;
    }
    return nullptr;
}

string ResourceManager::generateNewResourceId() {
    int maxNum = 0;
    for (auto &r : db.resources) {
        maxNum = max(maxNum, extractNumber(r.getResourceId()));
    }
    return fm.generateNextId("R", 3, maxNum);
}

void ResourceManager::displayResourceTable(const vector<Resource*> &list) {
    if (list.empty()) {
        printWarning("No resources found.");
        return;
    }
    cout << padRight("ID", 7) << padRight("RESOURCE NAME", 30) << padRight("TYPE", 18)
         << padRight("SUBJECT", 18) << padRight("STATUS", 10) << "\n";
    printLine('-', 83);
    for (auto *r : list) {
        cout << Color::CYAN << padRight(r->getResourceId(), 7) << Color::RESET
             << padRight(r->getName(), 30) << padRight(r->getType(), 18)
             << padRight(r->getSubject(), 18)
             << (r->isAvailable() ? Color::GREEN : Color::YELLOW)
             << padRight(r->getStatus(), 10) << Color::RESET << "\n";
    }
    printLine('-', 83);
    cout << "Total: " << list.size() << " resource(s)\n";
}

void ResourceManager::viewAllResources() {
    printHeader("ALL RESOURCES");
    vector<Resource*> list;
    for (auto &r : db.resources) list.push_back(&r);
    displayResourceTable(list);
}

void ResourceManager::viewByType(const string &type) {
    printHeader(type + " RESOURCES");
    vector<Resource*> list;
    for (auto &r : db.resources) {
        if (toLower(r.getType()) == toLower(type)) list.push_back(&r);
    }
    displayResourceTable(list);
}

void ResourceManager::viewSubjectWise() {
    string subject = readLine("Enter Subject Name (e.g. C++, DBMS, DSA): ");
    printHeader(subject + " RESOURCES");
    vector<Resource*> list;
    for (auto &r : db.resources) {
        if (containsIgnoreCase(r.getSubject(), subject)) list.push_back(&r);
    }
    displayResourceTable(list);
}

void ResourceManager::searchResources() {
    string keyword = readLine("Enter search keyword (ID/Name/Subject/Type/Author/Owner): ");
    if (!isNonEmpty(keyword)) { printError("Search keyword cannot be empty."); return; }

    vector<Resource*> results;
    for (auto &r : db.resources) {
        if (containsIgnoreCase(r.getResourceId(), keyword) || containsIgnoreCase(r.getName(), keyword) ||
            containsIgnoreCase(r.getSubject(), keyword) || containsIgnoreCase(r.getType(), keyword) ||
            containsIgnoreCase(r.getAuthor(), keyword) || containsIgnoreCase(r.getOwnerId(), keyword)) {
            results.push_back(&r);
        }
    }
    printHeader("SEARCH RESULTS");
    displayResourceTable(results);
}

void ResourceManager::filterResourcesMenu() {
    printSubHeader("FILTER RESOURCES");
    cout << "1. By Category/Type\n";
    cout << "2. By Subject\n";
    cout << "3. By Availability\n";
    cout << "4. By Owner\n";
    cout << "0. Back\n";
    int choice = readMenuChoice("Enter your choice: ", 0, 4);
    vector<Resource*> results;

    switch (choice) {
        case 1: {
            string type = readLine("Enter Type (Book/Notes/Assignment/Lab Report/Question Paper/PDF/Study Material/Programming Resource/Calculator/Laptop/Other): ");
            for (auto &r : db.resources) if (containsIgnoreCase(r.getType(), type)) results.push_back(&r);
            break;
        }
        case 2: {
            string subject = readLine("Enter Subject: ");
            for (auto &r : db.resources) if (containsIgnoreCase(r.getSubject(), subject)) results.push_back(&r);
            break;
        }
        case 3: {
            string avail = readLine("Available or Borrowed? ");
            for (auto &r : db.resources) if (containsIgnoreCase(r.getStatus(), avail)) results.push_back(&r);
            break;
        }
        case 4: {
            string owner = readLine("Enter Owner User ID: ");
            for (auto &r : db.resources) if (containsIgnoreCase(r.getOwnerId(), owner)) results.push_back(&r);
            break;
        }
        default: return;
    }
    printHeader("FILTERED RESULTS");
    displayResourceTable(results);
}

void ResourceManager::printResourceDetails(const Resource &r) {
    printHeader("RESOURCE DETAILS");
    cout << "Resource ID   : " << r.getResourceId() << "\n";
    cout << "Resource Name : " << r.getName() << "\n";
    cout << "Resource Type : " << r.getType() << "\n";
    cout << "Subject       : " << r.getSubject() << "\n";
    cout << "Description   : " << r.getDescription() << "\n";
    cout << "Author        : " << r.getAuthor() << "\n";
    cout << "Owner         : " << r.getOwnerId() << "\n";
    cout << "Condition     : " << r.getCondition() << "\n";
    cout << (r.isAvailable() ? Color::GREEN : Color::YELLOW)
         << "Availability  : " << r.getStatus() << Color::RESET << "\n";
    cout << "Borrower      : " << r.getBorrowerId() << "\n";
    cout << "Due Date      : " << r.getDueDate() << "\n";
    printLine('-');
}

int ResourceManager::viewResourceDetailsInteractive(string &outResourceId) {
    string id = readLine("Enter Resource ID to view: ");
    Resource *r = findById(id);
    if (!r) {
        printError("Resource not found.");
        return -1;
    }
    printResourceDetails(*r);
    outResourceId = id;
    cout << "1. Borrow\n2. Request\n3. Exchange\n0. Back\n";
    return readMenuChoice("Enter your choice: ", 0, 3);
}

void ResourceManager::resourceLibraryMenu(const string &currentUserId) {
    bool back = false;
    while (!back) {
        printHeader("RESOURCE LIBRARY");
        cout << "1. All Resources\n2. Books\n3. Notes\n4. Assignments\n5. Lab Reports\n"
             << "6. Previous Question Papers\n7. PDFs\n8. Study Materials\n"
             << "9. Programming Resources\n10. Calculators\n11. Laptops / Devices\n"
             << "12. Other Important Resources\n13. Subject-wise Resources\n"
             << "14. Search Resource\n15. Filter Resources\n0. Back\n";
        int choice = readMenuChoice("Enter your choice: ", 0, 15);
        switch (choice) {
            case 1: viewAllResources(); break;
            case 2: viewByType("Book"); break;
            case 3: viewByType("Notes"); break;
            case 4: viewByType("Assignment"); break;
            case 5: viewByType("Lab Report"); break;
            case 6: viewByType("Question Paper"); break;
            case 7: viewByType("PDF"); break;
            case 8: viewByType("Study Material"); break;
            case 9: viewByType("Programming Resource"); break;
            case 10: viewByType("Calculator"); break;
            case 11: viewByType("Laptop"); break;
            case 12: viewByType("Other"); break;
            case 13: viewSubjectWise(); break;
            case 14: searchResources(); break;
            case 15: filterResourcesMenu(); break;
            case 0: back = true; break;
        }
        if (!back) pauseScreen();
    }
}

void ResourceManager::addResource(User &owner) {
    printHeader("ADD RESOURCE");
    string name, type, subject, description, author, condition;

    while (true) { name = readLine("Resource Name: "); if (!isNonEmpty(name)) { printError("Name cannot be empty."); continue; } break; }
    while (true) { type = readLine("Resource Type (Book/Notes/Assignment/Lab Report/Question Paper/PDF/Study Material/Programming Resource/Calculator/Laptop/Other): "); if (!isNonEmpty(type)) { printError("Type cannot be empty."); continue; } break; }
    while (true) { subject = readLine("Subject: "); if (!isNonEmpty(subject)) { printError("Subject cannot be empty."); continue; } break; }
    description = readLine("Description: ");
    author = readLine("Author: ");
    while (true) { condition = readLine("Condition (e.g. Good/Fair/New): "); if (!isNonEmpty(condition)) { printError("Condition cannot be empty."); continue; } break; }

    string newId = generateNewResourceId();
    Resource newRes(newId, name, type, subject, description, owner.getUserId(), author, condition,
                     "Available", "None", "None");
    db.resources.push_back(newRes);
    owner.addCreditPoints(10);
    fm.saveData(db);

    printSuccess("Resource added successfully!");
    cout << Color::YELLOW << "Credit Points: +10 (Total: " << owner.getCreditPoints() << ")" << Color::RESET << "\n";
}

void ResourceManager::myResources(const string &userId) {
    printHeader("MY RESOURCES");
    vector<Resource*> list;
    for (auto &r : db.resources) if (r.getOwnerId() == userId) list.push_back(&r);
    displayResourceTable(list);
}

void ResourceManager::updateResource(const string &userId, bool isAdmin) {
    string id = readLine("Enter Resource ID to update: ");
    Resource *r = findById(id);
    if (!r) { printError("Resource not found."); return; }
    if (!isAdmin && r->getOwnerId() != userId) {
        printError("You are not authorized to update this resource.");
        return;
    }
    printInfo("Leave field blank to keep the current value.");
    string val;

    val = readLine("Name [" + r->getName() + "]: "); if (isNonEmpty(val)) r->setName(val);
    val = readLine("Type [" + r->getType() + "]: "); if (isNonEmpty(val)) r->setType(val);
    val = readLine("Subject [" + r->getSubject() + "]: "); if (isNonEmpty(val)) r->setSubject(val);
    val = readLine("Description [" + r->getDescription() + "]: "); if (isNonEmpty(val)) r->setDescription(val);
    val = readLine("Author [" + r->getAuthor() + "]: "); if (isNonEmpty(val)) r->setAuthor(val);
    val = readLine("Condition [" + r->getCondition() + "]: "); if (isNonEmpty(val)) r->setCondition(val);

    fm.saveData(db);
    printSuccess("Resource updated successfully.");
}

void ResourceManager::deleteResource(const string &userId, bool isAdmin) {
    string id = readLine("Enter Resource ID to delete: ");
    auto it = find_if(db.resources.begin(), db.resources.end(), [&](const Resource &r) {
        return r.getResourceId() == id;
    });
    if (it == db.resources.end()) { printError("Resource not found."); return; }
    if (!isAdmin && it->getOwnerId() != userId) {
        printError("You are not authorized to delete this resource.");
        return;
    }
    if (!isAdmin && it->getStatus() == "Borrowed") {
        printError("Cannot delete a resource that is currently borrowed.");
        return;
    }
    string confirm = readLine("Are you sure you want to delete this resource? (yes/no): ");
    if (toLower(confirm) != "yes") { printInfo("Delete cancelled."); return; }

    db.resources.erase(it);
    fm.saveData(db);
    printSuccess("Resource deleted successfully.");
}

void ResourceManager::adminAddResource() {
    printHeader("ADMIN: ADD RESOURCE");
    string name, type, subject, description, author, condition, ownerId;

    while (true) { name = readLine("Resource Name: "); if (!isNonEmpty(name)) { printError("Name cannot be empty."); continue; } break; }
    while (true) { type = readLine("Resource Type: "); if (!isNonEmpty(type)) { printError("Type cannot be empty."); continue; } break; }
    while (true) { subject = readLine("Subject: "); if (!isNonEmpty(subject)) { printError("Subject cannot be empty."); continue; } break; }
    description = readLine("Description: ");
    author = readLine("Author: ");
    condition = readLine("Condition: ");
    ownerId = readLine("Owner User ID (blank for Admin/University): ");
    if (!isNonEmpty(ownerId)) ownerId = "ADMIN";

    string newId = generateNewResourceId();
    Resource newRes(newId, name, type, subject, description, ownerId, author, condition,
                     "Available", "None", "None");
    db.resources.push_back(newRes);
    fm.saveData(db);
    printSuccess("Resource added successfully by Admin!");
}

void ResourceManager::adminViewAllResources() {
    viewAllResources();
}

int ResourceManager::countByStatus(const string &status) const {
    int c = 0;
    for (auto &r : db.resources) if (r.getStatus() == status) c++;
    return c;
}

int ResourceManager::countByType(const string &type) const {
    int c = 0;
    for (auto &r : db.resources) if (r.getType() == type) c++;
    return c;
}