#include "ExchangeRequest.h"
#include "Utils.h"
#include <sstream>

using namespace std;

ExchangeRequest::ExchangeRequest() : status("Pending") {}

ExchangeRequest::ExchangeRequest(string exchangeId, string senderId, string senderResourceId,
                                  string receiverId, string requestedResourceId,
                                  string date, string status)
    : exchangeId(exchangeId), senderId(senderId), senderResourceId(senderResourceId),
      receiverId(receiverId), requestedResourceId(requestedResourceId),
      date(date), status(status) {}

string ExchangeRequest::getExchangeId() const { return exchangeId; }
string ExchangeRequest::getSenderId() const { return senderId; }
string ExchangeRequest::getSenderResourceId() const { return senderResourceId; }
string ExchangeRequest::getReceiverId() const { return receiverId; }
string ExchangeRequest::getRequestedResourceId() const { return requestedResourceId; }
string ExchangeRequest::getDate() const { return date; }
string ExchangeRequest::getStatus() const { return status; }

void ExchangeRequest::setStatus(const string &v) { status = v; }

string ExchangeRequest::toLine() const {
    ostringstream oss;
    oss << exchangeId << "|" << senderId << "|" << senderResourceId << "|" << receiverId << "|"
        << requestedResourceId << "|" << date << "|" << status;
    return oss.str();
}

ExchangeRequest ExchangeRequest::fromLine(const string &line) {
    vector<string> f = splitLine(line, '|');
    while (f.size() < 7) f.push_back("");
    return ExchangeRequest(f[0], f[1], f[2], f[3], f[4], f[5], f[6]);
}