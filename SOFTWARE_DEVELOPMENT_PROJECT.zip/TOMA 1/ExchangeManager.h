#ifndef EXCHANGEMANAGER_H
#define EXCHANGEMANAGER_H

#include "Database.h"
#include "FileManager.h"
#include "ResourceManager.h"
#include "UserManager.h"

class ExchangeManager {
private:
    Database &db;
    FileManager &fm;
    ResourceManager &rm;
    UserManager &um;

    std::string generateNewExchangeId();

public:
    ExchangeManager(Database &db, FileManager &fm, ResourceManager &rm, UserManager &um);

    void exchangeResource(const std::string &userId);
    void exchangeResourceById(const std::string &userId, const std::string &requestedResourceId);
    void viewMyExchanges(const std::string &userId);
    void viewExchangeRequestsAdmin();
    void processExchangeAdmin();
};

#endif