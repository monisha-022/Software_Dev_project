#include "BorrowManager.h"
#include "Utils.h"
#include <iostream>
#include <algorithm>

using namespace std;

BorrowManager::BorrowManager(Database &db, FileManager &fm, ResourceManager &rm, UserManager &um)
    : db(db), fm(fm), rm(rm), um(um) {}

string BorrowManager::generateNewBorrowId() {
    int maxNum = 0;
    for (auto &b : db.borrowings) maxNum = max(maxNum, extractNumber(b.getBorrowId()));
    return fm.generateNextId("B", 3, maxNum);
}

void BorrowManager::borrowResourceById(const string &userId, const string &resourceId) {
    Resource *r = rm.findById(resourceId);
    if (!r) { printError("Resource not found."); return; }
    if (!r->isAvailable()) { printError("This resource is currently not available."); return; }
    if (r->getOwnerId() == userId) { printError("You cannot borrow your own resource."); return; }

    User *u = um.findByUserId(userId);
    if (!u) { printError("User not found."); return; }

    string borrowDate = getCurrentDate();
    string dueDate = addDaysToDate(borrowDate, 7);

    r->setStatus("Borrowed");
    r->setBorrowerId(userId);
    r->setDueDate(dueDate);

    string borrowId = generateNewBorrowId();
    db.borrowings.push_back(BorrowRecord(borrowId, userId, resourceId, r->getName(),
                                          borrowDate, dueDate, "None", "Borrowed"));
    fm.saveData(db);

    printHeader("RESOURCE BORROWED SUCCESSFULLY");
    cout << "Resource   : " << r->getName() << "\n";
    cout << "Borrow Date: " << borrowDate << "\n";
    cout << "Due Date   : " << dueDate << "\n";
    printLine('-');
}

void BorrowManager::borrowResource(const string &userId) {
    string resourceId = readLine("Enter Resource ID to borrow: ");
    borrowResourceById(userId, resourceId);
}

void BorrowManager::returnResource(const string &userId) {
    string resourceId = readLine("Enter Resource ID to return: ");
    Resource *r = rm.findById(resourceId);
    if (!r) { printError("Resource not found."); return; }
    if (r->getBorrowerId() != userId) {
        printError("You have not borrowed this resource.");
        return;
    }

    BorrowRecord *record = nullptr;
    for (auto &b : db.borrowings) {
        if (b.getResourceId() == resourceId && b.getUserId() == userId &&
            (b.getStatus() == "Borrowed" || b.getStatus() == "Overdue")) {
            record = &b;
        }
    }
    if (!record) { printError("No active borrowing record found."); return; }

    string returnDate = getCurrentDate();
    bool onTime = compareDates(returnDate, record->getDueDate()) <= 0;

    record->setReturnDate(returnDate);
    record->setStatus("Returned");

    r->setStatus("Available");
    r->setBorrowerId("None");
    r->setDueDate("None");

    User *u = um.findByUserId(userId);
    int delta = 0;
    if (u) {
        delta = onTime ? 5 : -5;
        u->addCreditPoints(delta);
    }

    fm.saveData(db);

    printSuccess("Resource returned successfully!");
    if (onTime) {
        cout << Color::GREEN << "Returned on time. Credit Points: +5" << Color::RESET << "\n";
    } else {
        cout << Color::RED << "Returned late. Credit Points: -5" << Color::RESET << "\n";
    }
    if (u) cout << "Total Credit Points: " << u->getCreditPoints() << "\n";
}

void BorrowManager::checkAndUpdateOverdue() {
    string today = getCurrentDate();
    for (auto &b : db.borrowings) {
        if (b.getStatus() == "Borrowed" && compareDates(today, b.getDueDate()) > 0) {
            b.setStatus("Overdue");
        }
    }
    fm.saveData(db);
}

void BorrowManager::viewBorrowingHistory(const string &userId, bool isAdmin) {
    printHeader(isAdmin ? "ALL BORROWING RECORDS" : "MY BORROWING HISTORY");
    cout << padRight("ID", 6) << padRight("USER", 7) << padRight("RESOURCE", 28)
         << padRight("BORROW DATE", 13) << padRight("DUE DATE", 12)
         << padRight("RETURN DATE", 13) << padRight("STATUS", 10) << "\n";
    printLine('-', 89);

    bool found = false;
    for (auto &b : db.borrowings) {
        if (!isAdmin && b.getUserId() != userId) continue;
        found = true;
        string color = Color::GREEN;
        if (b.getStatus() == "Overdue") color = Color::RED;
        else if (b.getStatus() == "Borrowed") color = Color::YELLOW;

        cout << padRight(b.getBorrowId(), 6) << padRight(b.getUserId(), 7)
             << padRight(b.getResourceName(), 28) << padRight(b.getBorrowDate(), 13)
             << padRight(b.getDueDate(), 12) << padRight(b.getReturnDate(), 13)
             << color << padRight(b.getStatus(), 10) << Color::RESET << "\n";
    }
    if (!found) printInfo("No borrowing records found.");
    printLine('-', 89);
}

void BorrowManager::viewOverdueResources(const string &userId, bool isAdmin) {
    checkAndUpdateOverdue();
    printHeader("OVERDUE RESOURCES");
    bool found = false;
    for (auto &b : db.borrowings) {
        if (b.getStatus() != "Overdue") continue;
        if (!isAdmin && b.getUserId() != userId) continue;
        found = true;
        cout << Color::RED;
        printLine('=');
        cout << "WARNING: OVERDUE RESOURCE\n\n";
        cout << "Resource : " << b.getResourceName() << "\n";
        cout << "User ID  : " << b.getUserId() << "\n";
        cout << "Due Date : " << b.getDueDate() << "\n";
        cout << "Status   : OVERDUE\n";
        printLine('=');
        cout << Color::RESET;
    }
    if (!found) printInfo("No overdue resources found.");
}