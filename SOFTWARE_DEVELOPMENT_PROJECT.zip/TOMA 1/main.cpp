#include <iostream>
#include "Utils.h"
#include "Database.h"
#include "FileManager.h"
#include "User.h"
#include "UserManager.h"
#include "ResourceManager.h"
#include "BorrowManager.h"
#include "RequestManager.h"
#include "ExchangeManager.h"
#include "ReportManager.h"

using namespace std;

static void studentDashboard(User &student, UserManager &um, ResourceManager &rm,
                              BorrowManager &bm, RequestManager &reqm, ExchangeManager &em,
                              ReportManager &repm) {
    bool logout = false;
    while (!logout) {
        printHeader("STUDENT DASHBOARD");
        cout << "Welcome, " << Color::BOLD << student.getName() << Color::RESET << "\n";
        printLine('-');
        cout << "1. View Profile\n2. View Resource Library\n3. Add Resource\n4. My Resources\n"
             << "5. Search Resource\n6. Update Resource\n7. Delete Resource\n8. Borrow Resource\n"
             << "9. Return Resource\n10. Request Resource\n11. Exchange Resource\n"
             << "12. Borrowing History\n13. Credit Points\n14. Contributor Leaderboard\n"
             << "15. Overdue Resources\n0. Logout\n";
        printLine('-');
        int choice = readMenuChoice("Enter your choice: ", 0, 15);

        switch (choice) {
            case 1: um.viewProfile(student); break;
            case 2: rm.resourceLibraryMenu(student.getUserId()); break;
            case 3: rm.addResource(student); break;
            case 4: rm.myResources(student.getUserId()); break;
            case 5: rm.searchResources(); break;
            case 6: rm.updateResource(student.getUserId(), false); break;
            case 7: rm.deleteResource(student.getUserId(), false); break;
            case 8: bm.borrowResource(student.getUserId()); break;
            case 9: bm.returnResource(student.getUserId()); break;
            case 10: reqm.requestResource(student.getUserId()); break;
            case 11: em.exchangeResource(student.getUserId()); break;
            case 12: bm.viewBorrowingHistory(student.getUserId(), false); break;
            case 13: {
                printHeader("MY CREDIT POINTS");
                cout << "Current Credit Points: " << Color::YELLOW << student.getCreditPoints()
                     << Color::RESET << "\n";
                break;
            }
            case 14: repm.viewLeaderboard(); break;
            case 15: bm.viewOverdueResources(student.getUserId(), false); break;
            case 0:
                logout = true;
                printInfo("Logging out...");
                break;
        }
        if (!logout) pauseScreen();
    }
}

static void adminDashboard(UserManager &um, ResourceManager &rm, BorrowManager &bm,
                            RequestManager &reqm, ExchangeManager &em, ReportManager &repm) {
    bool logout = false;
    while (!logout) {
        printHeader("ADMIN DASHBOARD");
        cout << "1. View All Users\n2. Search User\n3. View All Resources\n4. Add Resource\n"
             << "5. Update Resource\n6. Delete Resource\n7. View Borrowing Records\n"
             << "8. View Pending Requests\n9. View Exchange Requests\n10. View Overdue Resources\n"
             << "11. View Contributor Leaderboard\n12. Resource Statistics\n13. Generate Reports\n"
             << "14. Delete User\n15. Process Request\n16. Process Exchange\n0. Logout\n";
        printLine('-');
        int choice = readMenuChoice("Enter your choice: ", 0, 16);

        switch (choice) {
            case 1: um.viewAllUsersAdmin(); break;
            case 2: um.searchUsersAdmin(); break;
            case 3: rm.adminViewAllResources(); break;
            case 4: rm.adminAddResource(); break;
            case 5: rm.updateResource("", true); break;
            case 6: rm.deleteResource("", true); break;
            case 7: bm.viewBorrowingHistory("", true); break;
            case 8: reqm.viewPendingRequestsAdmin(); break;
            case 9: em.viewExchangeRequestsAdmin(); break;
            case 10: bm.viewOverdueResources("", true); break;
            case 11: repm.viewLeaderboard(); break;
            case 12: repm.viewResourceStatistics(); break;
            case 13: repm.generateAllReportsMenu(); break;
            case 14: um.deleteUserAdmin(); break;
            case 15: reqm.processRequestAdmin(); break;
            case 16: em.processExchangeAdmin(); break;
            case 0:
                logout = true;
                printInfo("Logging out...");
                break;
        }
        if (!logout) pauseScreen();
    }
}

int main() {
    Database db;
    FileManager fm("database.txt");
    fm.initializeDatabase(db);

    UserManager um(db, fm);
    ResourceManager rm(db, fm);
    BorrowManager bm(db, fm, rm, um);
    RequestManager reqm(db, fm, rm);
    ExchangeManager em(db, fm, rm, um);
    ReportManager repm(db, rm);

    bm.checkAndUpdateOverdue();

    bool running = true;
    while (running) {
        printHeader("SMART UNIVERSITY RESOURCE EXCHANGE SYSTEM");
        cout << "\n                Welcome to the System\n\n";
        printLine('-');
        cout << "1. Student Registration\n2. Student Login\n3. Admin Login\n0. Exit\n";
        printLine('-');
        int choice = readMenuChoice("Enter your choice: ", 0, 3);

        switch (choice) {
            case 1:
                um.registerStudent();
                pauseScreen();
                break;
            case 2: {
                string idOrStudentId = readLine("User ID / Student ID: ");
                string password = readPassword("Password: ");
                User *u = um.login(idOrStudentId, password);
                if (u) {
                    printSuccess("Login successful!");
                    studentDashboard(*u, um, rm, bm, reqm, em, repm);
                } else {
                    printLine('-');
                    printError("Invalid User ID or Password.");
                    cout << "Please try again.\n";
                    printLine('-');
                    pauseScreen();
                }
                break;
            }
            case 3: {
                string username = readLine("Admin Username: ");
                string password = readPassword("Admin Password: ");
                if (um.adminLogin(username, password)) {
                    printSuccess("Admin login successful!");
                    adminDashboard(um, rm, bm, reqm, em, repm);
                } else {
                    printError("Invalid admin credentials.");
                    pauseScreen();
                }
                break;
            }
            case 0:
                running = false;
                cout << Color::CYAN << "\nThank you for using Smart University Resource Exchange System.\n";
                cout << "Goodbye!\n" << Color::RESET;
                break;
        }
    }

    return 0;
}