#ifndef REQUEST_H
#define REQUEST_H

#include <string>

class Request {
private:
    std::string requestId;
    std::string requesterId;
    std::string resourceId;
    std::string ownerId;
    std::string requestDate;
    std::string status;

public:
    Request();
    Request(std::string requestId, std::string requesterId, std::string resourceId,
            std::string ownerId, std::string requestDate, std::string status);

    std::string getRequestId() const;
    std::string getRequesterId() const;
    std::string getResourceId() const;
    std::string getOwnerId() const;
    std::string getRequestDate() const;
    std::string getStatus() const;

    void setStatus(const std::string &v);

    std::string toLine() const;
    static Request fromLine(const std::string &line);
};

#endif